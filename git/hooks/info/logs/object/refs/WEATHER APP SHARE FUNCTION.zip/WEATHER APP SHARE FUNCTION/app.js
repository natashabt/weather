const inputBox = document.querySelector(".input-box");
const searchBtn = document.querySelector("#searchBtn");
const weatherIcon = document.querySelector(".weather-icon");
const temperature = document.querySelector(".temp");
const city = document.querySelector(".city");
const humidity = document.querySelector(".humidity");
const windSpeed = document.querySelector(".wind");
const shareBtn = document.getElementById('share-btn');

async function checkWeather(cityName) {
    const apiKey = "cafc96270815c9091cf3aeb1569f8322"; // Replace with your valid OpenWeather API key
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${apiKey}&units=metric`;

    try {
        const response = await fetch(url);

        if (!response.ok) {
            throw new Error("City not found. Please check the city name.");
        }

        const weatherData = await response.json();

        // Update UI with fetched weather data
        temperature.innerHTML = `${weatherData.main.temp}°C`;
        humidity.innerHTML = `${weatherData.main.humidity}%`;
        windSpeed.innerHTML = `${(weatherData.wind.speed * 3.6).toFixed(2)} km/h`;
        city.innerHTML = `${weatherData.name}`;
    } catch (error) {
        alert(error.message);
        console.error("Error fetching weather data:", error);
    }
}

searchBtn.addEventListener('click', () => {
    const cityName = inputBox.value.trim();
    if (cityName) {
        checkWeather(cityName);
    } else {
        alert("Please enter a city name.");
    }
});

// Share weather data
shareBtn.addEventListener('click', () => {
    const weatherInfo = `City: ${city.textContent}, Temp: ${temperature.textContent}, Humidity: ${humidity.textContent}, Wind Speed: ${windSpeed.textContent}`;
    if (navigator.share) {
        navigator.share({
            title: 'Weather Information',
            text: weatherInfo
        }).then(() => console.log('Shared successfully'))
          .catch(err => console.error('Error sharing:', err));
    } else {
        navigator.clipboard.writeText(weatherInfo)
            .then(() => alert('Weather information copied to clipboard!'))
            .catch(err => console.error('Error copying text:', err));
    }
});
